package com.iwgame.app.iwsdk.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.iwgame.app.iwsdk.base.XConstants;

public class IWUtils {
	private static final String TAG = XConstants.IWSDK_TAG;

	public static String getEnvInfo(Activity context) {
		JSONObject json = new JSONObject();
		try {
			json.put("did", new DeviceUuidFactory(context).getDeviceUuid());
			json.put("apd", getMetaData(context, "iw_appid"));
			json.put("gfg", getMetaData(context, "iw_gameid"));
			json.put("chi", getMetaData(context, "iw_chnid"));
			json.put("rst", getMetaData(context, "iw_srtype"));
			json.put("rsv", getMetaData(context, "iw_srid"));
			json.put("os", "a");
			json.put("osv", getOSInfo());
			json.put("nt", getNetworkType(context));
			json.put("ip", getHostIP());
			json.put("mac", getMacAddress(context));
			return json.toString();
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 获取ip地址
	 * 
	 * @return
	 */
	public static String getHostIP() {

		String hostIp = null;
		try {
			Enumeration<?> nis = NetworkInterface.getNetworkInterfaces();
			InetAddress ia = null;
			while (nis.hasMoreElements()) {
				NetworkInterface ni = (NetworkInterface) nis.nextElement();
				Enumeration<InetAddress> ias = ni.getInetAddresses();
				while (ias.hasMoreElements()) {
					ia = ias.nextElement();
					if (ia instanceof Inet6Address) {
						continue;// skip ipv6
					}
					String ip = ia.getHostAddress();
					if (!"127.0.0.1".equals(ip)) {
						hostIp = ia.getHostAddress();
						break;
					}
				}
			}
		} catch (SocketException e) {
			Log.i("yao", "SocketException");
			e.printStackTrace();
		}
		return hostIp;

	}

	public static String getOSInfo() {
		return android.os.Build.MODEL + "," + android.os.Build.VERSION.SDK_INT
				+ "," + android.os.Build.VERSION.RELEASE;
	}

	public static String getNetworkType(Activity context) {
		String strNetworkType = "";
		try {

			NetworkInfo networkInfo = ((ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE))
					.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
					strNetworkType = "WIFI";
				} else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
					String _strSubTypeName = networkInfo.getSubtypeName();

					Log.e("cocos2d-x", "Network getSubtypeName : "
							+ _strSubTypeName);

					// TD-SCDMA networkType is 17
					int networkType = networkInfo.getSubtype();
					switch (networkType) {
					case TelephonyManager.NETWORK_TYPE_GPRS:
					case TelephonyManager.NETWORK_TYPE_EDGE:
					case TelephonyManager.NETWORK_TYPE_CDMA:
					case TelephonyManager.NETWORK_TYPE_1xRTT:
					case TelephonyManager.NETWORK_TYPE_IDEN: // api<8 : replace
																// by
																// 11
						strNetworkType = "2G";
						break;
					case TelephonyManager.NETWORK_TYPE_UMTS:
					case TelephonyManager.NETWORK_TYPE_EVDO_0:
					case TelephonyManager.NETWORK_TYPE_EVDO_A:
					case TelephonyManager.NETWORK_TYPE_HSDPA:
					case TelephonyManager.NETWORK_TYPE_HSUPA:
					case TelephonyManager.NETWORK_TYPE_HSPA:
					case TelephonyManager.NETWORK_TYPE_EVDO_B: // api<9 :
																// replace by
																// 14
					case TelephonyManager.NETWORK_TYPE_EHRPD: // api<11 :
																// replace by
																// 12
					case TelephonyManager.NETWORK_TYPE_HSPAP: // api<13 :
																// replace by
																// 15
						strNetworkType = "3G";
						break;
					case TelephonyManager.NETWORK_TYPE_LTE: // api<11 : replace
															// by
															// 13
						strNetworkType = "4G";
						break;
					default:
						// http://baike.baidu.com/item/TD-SCDMA 中国移动 联通 电信
						// 三种3G制式
						if (_strSubTypeName.equalsIgnoreCase("TD-SCDMA")
								|| _strSubTypeName.equalsIgnoreCase("WCDMA")
								|| _strSubTypeName.equalsIgnoreCase("CDMA2000")) {
							strNetworkType = "3G";
						} else {
							strNetworkType = _strSubTypeName;
						}

						break;
					}

					Log.e(TAG,
							"Network getSubtype : "
									+ Integer.valueOf(networkType).toString());
				}
			}

			Log.e(TAG, "Network Type : " + strNetworkType);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strNetworkType;
	}

	/**
	 * 获取mac地址
	 * 
	 * @param activity
	 * @return
	 */
	public static String getMacAddress(Activity activity) {
		WifiManager localWifiManager = (WifiManager) activity
				.getSystemService("wifi");
		WifiInfo localWifiInfo = localWifiManager == null ? null
				: localWifiManager.getConnectionInfo();
		if (localWifiInfo != null) {
			String str = localWifiInfo.getMacAddress();
			if ((str == null) || (str.equals(""))) {
				str = "null";
			}
			return str;
		}
		return "null";
	}

	/***
	 * 网络是否可用
	 * 
	 * @param activity
	 * @return
	 */
	public static boolean isNetworkAvailable(Context activity) {
		try {
			ConnectivityManager connectivityManager = (ConnectivityManager) activity
					.getSystemService("connectivity");
			NetworkInfo localNetworkInfo = connectivityManager
					.getActiveNetworkInfo();
			return localNetworkInfo != null && localNetworkInfo.isAvailable();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;

	}

	public static boolean isNullOrEmpty(String str) {

		return str == null || str.trim().length() == 0;
	}

	/***
	 * 获取assets目录下文件内容
	 * 
	 * @param context
	 * @param assetsFile
	 * @return
	 */
	public static String getAssetConfigs(Context context, String assetsFile) {
		InputStreamReader reader = null;
		BufferedReader br = null;
		try {
			reader = new InputStreamReader(context.getAssets().open(assetsFile));
			br = new BufferedReader(reader);

			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

			return sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
					br = null;
				} catch (IOException e) {
					e.printStackTrace();
				}

			}

			if (reader != null) {
				try {
					reader.close();
					reader = null;
				} catch (IOException e) {
					e.printStackTrace();
				}

			}
		}
		return null;
	}

	/**
	 * 获取assets目录下面指定的.properties文件内容
	 * 
	 * @param context
	 * @param assetsPropertiesFile
	 * @return
	 */
	public static Map<String, String> getAssetPropConfig(Context context,
			String assetsPropertiesFile) {
		try {
			Properties pro = new Properties();
			pro.load(new InputStreamReader(context.getAssets().open(
					assetsPropertiesFile), "UTF-8"));

			Map<String, String> result = new HashMap<String, String>();

			for (Entry<Object, Object> entry : pro.entrySet()) {
				String keyStr = entry.getKey().toString().trim();
				String keyVal = entry.getValue().toString().trim();
				if (!result.containsKey(keyStr)) {
					result.put(keyStr, keyVal);
				}
			}

			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	/***
	 * 获取Manifest.xml 中MetaData属性
	 * 
	 * @param activity
	 * @param key
	 * @return
	 */
	public static String getMetaData(Context ctx, String key) {
		try {
			ApplicationInfo appInfo = ctx.getPackageManager()
					.getApplicationInfo(ctx.getPackageName(),
							PackageManager.GET_META_DATA);
			if (appInfo != null && appInfo.metaData != null
					&& appInfo.metaData.containsKey(key)) {

				return "" + appInfo.metaData.get(key);
			} else {
				Log.e(TAG, "The meta-data key is not exists." + key);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
