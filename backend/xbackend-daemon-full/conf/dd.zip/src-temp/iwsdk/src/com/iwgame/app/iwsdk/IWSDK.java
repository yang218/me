package com.iwgame.app.iwsdk;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.iwgame.app.iwsdk.activity.ContainerActivity;
import com.iwgame.app.iwsdk.base.XCallbackManager;
import com.iwgame.app.iwsdk.base.XConstants;
import com.iwgame.app.iwsdk.base.XConstants.IDKeys;
import com.iwgame.app.iwsdk.base.XDispatcherCallback;
import com.iwgame.app.iwsdk.util.FloatUtil;

public class IWSDK {
	private static final String TAG = "IWSDK";
	
	private static IWSDK instance = new IWSDK();

	private Activity context;

	private boolean isInited;

	private boolean isPor;

	private IWSDK() {

	}

	public static IWSDK getInstance() {
		return instance;
	}
	
	public boolean isPor() {
		return isPor;
	}

	public Activity getTargetActivity() {
		return context;
	}

	public void init(Activity paramActivity, boolean isPor) {
		if (isInited) {
			return;
		}

		if (paramActivity == null) {
			Log.w(TAG, "Activity Param is null");
			return;
		}
		paramActivity.runOnUiThread(new Runnable() {
			public void run() {
				try {
					Class.forName("android.os.AsyncTask");
				} catch (ClassNotFoundException e) {
					Log.e(TAG, e.toString());
				}
			}
		});
		context = paramActivity;
		isInited = true;
		this.isPor = isPor;
		Log.d(TAG, "init ok...");
	}

	public void loginAccount(XDispatcherCallback callback) {
		Log.i(TAG, "loginAccount...");
		invokeActivity(context, buildIntent(XConstants.FUNC_CODE_LOGIN, isPor),
				callback);
	}

	public void pay(XDispatcherCallback callback) {
		Log.i(TAG, "pay...");
		Toast.makeText(context, "支付接口暂未对接,忽略执行...", Toast.LENGTH_SHORT).show();
		return;
		// invokeActivity(context, buildIntent(XConstants.FUNC_CODE_PAY, isPor),
		// callback);
	}

	public void swichAccount(XDispatcherCallback callback) {
		Log.i(TAG, "swichAccount...");
		invokeActivity(context, buildIntent(XConstants.FUNC_CODE_SWICH, isPor),
				callback);
	}

	public void bindAccount(XDispatcherCallback callback) {
		Log.i(TAG, "bindAccount...");
		invokeActivity(context, buildIntent(XConstants.FUNC_CODE_BIND, isPor),
				callback);
	}

	public void destory() {
		Log.i(TAG, "destroy...");
		FloatUtil.getInstance().removeFloatView();
	}

	public void quitSDK(XDispatcherCallback callback) {
		Log.i(TAG, "quit...");
		invokeActivity(context, buildIntent(XConstants.FUNC_CODE_QUIT, isPor),
				callback);
	}

	public void invokeActivity(Context paramContext, Intent paramIntent,
			XDispatcherCallback paramIDispatcherCallback) {
		Log.d(TAG, "invokeActivity...");
		if (!isInited) {
			if (paramIDispatcherCallback != null) {
				paramIDispatcherCallback.onFinished(-1, "SDK");
			}
			return;
		}
		paramIntent.setClass(paramContext, ContainerActivity.class);
		Long flag = XCallbackManager.registCallback(paramIDispatcherCallback);
		paramIntent.putExtra(IDKeys.CALLBACK_ID, flag);
		paramContext.startActivity(paramIntent);
		Log.i(TAG, "invokeActivity");
	}

	private Intent buildIntent(int code, boolean isPor) {
		Intent baseIntent = new Intent();
		baseIntent.putExtra(XConstants.IDKeys.FUNCTION_CODE, code);
		baseIntent.putExtra(XConstants.IDKeys.SCREEN_ORIENTATION_ID, isPor);
		return baseIntent;
	}
}
