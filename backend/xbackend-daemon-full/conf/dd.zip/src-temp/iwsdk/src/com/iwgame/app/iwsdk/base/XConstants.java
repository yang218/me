package com.iwgame.app.iwsdk.base;

public interface XConstants {

	public static final String IWSDK_TAG = "iwsdk";

	public static final String SDK_VERSION = "1.0.0";

	public static final int FUNC_CODE_LOGIN = 100;
	public static final int FUNC_CODE_SWICH = 101;
	public static final int FUNC_CODE_PAY = 200;
	public static final int FUNC_CODE_CENTER = 300;
	public static final int FUNC_CODE_BIND = 301;
	public static final int FUNC_CODE_QUIT = 400;

	public static final int RESULT_CODE_FAIL = 0;
	public static final int RESULT_CODE_OK = 1;
	public static final int RESULT_CODE_SERVER_SUCCESS = 0;
	public static final int RESULT_CODE_QUIT = 2;

	public interface IDKeys {
		public static final String FUNCTION_CODE = "functionCode";
		public static final String CALLBACK_ID = "callbackId";
		public static final String SCREEN_ORIENTATION_ID = "screenOri";
	}
}
