package com.iwgame.app.iwsdk.model;

public class EnvObj {
	private String did;
	private String apd;
	private String chi;
	private String gfg;
	private String rsv;
	private String rst;
	private String os;
	private String osv;

	public String getDid() {
		return did;
	}

	public void setDid(String did) {
		this.did = did;
	}

	public String getApd() {
		return apd;
	}

	public void setApd(String apd) {
		this.apd = apd;
	}

	public String getChi() {
		return chi;
	}

	public void setChi(String chi) {
		this.chi = chi;
	}

	public String getGfg() {
		return gfg;
	}

	public void setGfg(String gfg) {
		this.gfg = gfg;
	}

	public String getRsv() {
		return rsv;
	}

	public void setRsv(String rsv) {
		this.rsv = rsv;
	}

	public String getRst() {
		return rst;
	}

	public void setRst(String rst) {
		this.rst = rst;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public String getOsv() {
		return osv;
	}

	public void setOsv(String osv) {
		this.osv = osv;
	}
}