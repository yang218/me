/** Automatically generated file. DO NOT MODIFY */
package com.iwgame.app.iwsdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}