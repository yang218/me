package com.iwgame.app.iwsdk.activity;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.json.JSONException;
import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebView.HitTestResult;
import android.webkit.WebViewClient;

import com.iwgame.app.iwsdk.IWSDK;
import com.iwgame.app.iwsdk.base.XCallbackManager;
import com.iwgame.app.iwsdk.base.XConstants;
import com.iwgame.app.iwsdk.base.XConstants.IDKeys;
import com.iwgame.app.iwsdk.base.XDispatcherCallback;
import com.iwgame.app.iwsdk.util.DeviceUuidFactory;
import com.iwgame.app.iwsdk.util.IWUtils;
import com.iwgame.app.iwsdk.util.XHttpUtils;

@SuppressLint({ "SetJavaScriptEnabled" })
public class ContainerActivity extends Activity {

	private static final String BASE_PAGE = "http://passport.iwgame.test/app/apppage.do";

	private static final String LAST_FLAG = "last.flag";

	private static final String TAG = "x8-ContainerActivity";

	private static final String STORE_FLAG = "iwstore.sp";

	private static int curFC;
	private static long curCBD;

	private WebView webView;

	private Handler mHandler = new Handler();

	@JavascriptInterface
	public void onHandleBack(final int bt, final int ec, final String data) {
		Log.d(TAG, "jsback-bt=" + curFC + ",ec=" + ec + ",data=" + data);
		mHandler.post(new Runnable() {

			@Override
			public void run() {
				Log.d(TAG, "to excute resp opt...");
				int code = ec;
				if (XConstants.RESULT_CODE_OK == ec) {
					Log.d(TAG, "view返回结果成功：" + data);
					code = handleData(curFC, data);
				}
				response(code, data);
			}
		});
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Log.i(TAG, "onCreate....");
		Intent reqIntent = getIntent();
		Bundle extras = reqIntent.getExtras();
		final int fc = extras.getInt(IDKeys.FUNCTION_CODE, 0);
		long cid = extras.getLong(IDKeys.CALLBACK_ID, 0);

		Log.d(TAG, "function code：" + fc + ",callbackid=" + cid
				+ ",isScreenPort=" + IWSDK.getInstance().isPor());
		if (fc == 0 || cid == 0) {
			// 异常信息页面
			Log.e(TAG, "调用的接口标识无效,fc=" + fc + ",cid=" + cid);
			ContainerActivity.this.finish();
			return;
		}
		if (IWSDK.getInstance().isPor()) {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		curFC = fc;
		curCBD = cid;
		String dat = "";
		// 获取业务数据
		SharedPreferences sp;
		switch (curFC) {
		case XConstants.FUNC_CODE_LOGIN:
			// 普通登录
			VTTask vtTask = new VTTask();
			vtTask.execute("");
			return;
		case XConstants.FUNC_CODE_SWICH:
			// 切换帐号-登录过的帐号列表
			sp = ContainerActivity.this.getSharedPreferences(STORE_FLAG,
					MODE_PRIVATE);
			Map<String, ?> allAccs = sp.getAll();
			Set<String> ks = allAccs.keySet();
			if (ks.size() > 0) {
				StringBuilder sb = new StringBuilder();
				sb.append("[");
				for (String k : ks) {
					if (LAST_FLAG.equals(k)) {
						continue;
					}
					sb.append(allAccs.get(k));
					sb.append(",");
				}
				dat = sb.substring(0, sb.length() - 1) + "]";
			} else {
				dat = "[]";
			}
			break;
		case XConstants.FUNC_CODE_BIND:
			// 绑定通行证-当前登录帐号信息
			sp = ContainerActivity.this.getSharedPreferences(STORE_FLAG,
					MODE_PRIVATE);
			String last = sp.getString(LAST_FLAG, null);
			if (last == null) {
				response(XConstants.RESULT_CODE_FAIL, "需要先登录帐号");
				return;
			}
			try {
				JSONObject jo = new JSONObject(last);
				if (!"1".equals(jo.getString("type"))) {
					// 非游客帐号不能绑定
					response(XConstants.RESULT_CODE_FAIL, "帐号不需要绑定");
					return;
				}
			} catch (JSONException e) {
				e.printStackTrace();
				response(XConstants.RESULT_CODE_FAIL, "需要先登录帐号");
				return;
			}
			dat = last;
			break;
		case XConstants.FUNC_CODE_PAY:
			// 无
			return;
		case XConstants.FUNC_CODE_QUIT:
			// 无

			break;
		default:
			break;
		}
		String env = IWUtils.getEnvInfo(this);
		if (env == null) {
			env = "";
		}
		Log.d(TAG, "-----行为代号:" + fc);
		Log.d(TAG, "-----业务数据:" + dat);
		Log.d(TAG, "-----环境数据:" + env);
		// iwsLoadData(_bt,_dat,_env);业务类型，业务数据，环境信息
		initWebView(BASE_PAGE, fc, dat, env);
		// initWebView("http://192.168.22.64:8086/login.html", fc, dat, env);
	}
	
	@Override
	protected void onStart() {
		super.onStart();
		Log.i(TAG, "onStart...");
	}

	@Override
	protected void onResume() {
		super.onResume();
		Log.i(TAG, "onResume...");
	}

	@Override
	protected void onPause() {
		super.onPause();
		Log.i(TAG, "onPause...");

	}

	@Override
	protected void onStop() {
		super.onStop();
		Log.i(TAG, "onStop...");

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.i(TAG, "onDestroy...");
		curFC = 0;
		curCBD = 0;
	}

	@Override
	// 设置回退
	// 覆盖Activity类的onKeyDown(int keyCoder,KeyEvent event)方法
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if ((keyCode == KeyEvent.KEYCODE_BACK)) {
			Log.d(TAG, "ready to back pre activity...");
			if (webView.canGoBack()) {
				webView.goBack(); // goBack()表示返回WebView的上一页面
			} else {
				ContainerActivity.this.finish();
			}
			return true;
		}
		return false;
	}

	private void initWebView(String url, final int fc, final String dat,
			final String env) {
		webView = new WebView(this);
		// 启用支持javascript
		webView.getSettings().setJavaScriptEnabled(true);
		webView.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
		webView.addJavascriptInterface(this, "iwsdk");
		// WebView加载web资源
		webView.loadUrl(url);
		webView.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onShowCustomView(View view, CustomViewCallback callback) {
				super.onShowCustomView(view, callback);
				Log.e("tag", "on Show Custom View >>>>>webView");

			}
		});
		// 覆盖WebView默认使用第三方或系统默认浏览器打开网页的行为，使网页用WebView打开
		webView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				// 返回值是true的时候控制去WebView打开，为false调用系统浏览器或第三方浏览器
				HitTestResult hit = view.getHitTestResult();
				if (hit != null) {
					int hitType = hit.getType();
					if (hitType == HitTestResult.SRC_ANCHOR_TYPE
							|| hitType == HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {// 点击超链接
						Intent i = new Intent(Intent.ACTION_VIEW);
						i.setData(Uri.parse(url));
						startActivity(i);
						return false;
					}
				}
				view.loadUrl(url);
				return true;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				super.onPageFinished(view, url);
				mHandler.post(new Runnable() {
					@Override
					public void run() {
						webView.loadUrl("javascript:iwsLoadData('" + fc + "','"
								+ dat + "','" + env + "')");
					}
				});
			}
		});
		setContentView(webView);
	}

	private int handleData(int bt, String data) {
		if (XConstants.FUNC_CODE_LOGIN == bt
				|| XConstants.FUNC_CODE_SWICH == bt
				|| XConstants.FUNC_CODE_BIND == bt) {
			// 存储帐号信息
			JSONObject jo = null;
			String aid = null;
			try {
				jo = new JSONObject(data);
				aid = jo.getString("aid");
			} catch (Exception e) {
				Log.e(TAG, "解析view回调结果异常,数据串=" + data, e);
				return XConstants.RESULT_CODE_FAIL;
			}
			if (TextUtils.isEmpty(aid)) {
				Log.e(TAG, "view回调结果异常,帐号编号aid缺失,数据串=" + data);
				return XConstants.RESULT_CODE_FAIL;
			}
			SharedPreferences sp = ContainerActivity.this.getSharedPreferences(
					STORE_FLAG, MODE_PRIVATE);
			sp.edit().putString(aid, data).putString(LAST_FLAG, data).commit();
			Log.d(TAG, "存储完成：" + data);
		} else {
			// 忽略处理
			Log.d(TAG, "忽略处理业务:" + bt);
		}
		return XConstants.RESULT_CODE_OK;
	}

	class VTTask extends AsyncTask<String, Void, String> {

		@Override
		protected String doInBackground(String... args) {
			// 校验获取最近一次登录用户token
			SharedPreferences sp = ContainerActivity.this.getSharedPreferences(
					STORE_FLAG, MODE_PRIVATE);
			String lastLoginData = sp.getString(LAST_FLAG, null);
			try {
				if (lastLoginData == null) {
					return null;
				}
				JSONObject jo = new JSONObject(lastLoginData);
				String tkn = jo.getString("token");
				HashMap<String, String> pm = new HashMap<String, String>();
				pm.put("appid", "2");
				pm.put("token", tkn);
				pm.put("did", new DeviceUuidFactory(ContainerActivity.this)
						.getDeviceUuid().toString());
				Log.d(TAG,
						"token校验请求:http://passport.iwgame.test/app/cktsdk.do");
				String result = XHttpUtils.httpPost(
						"http://passport.iwgame.test/app/cktsdk.do", pm);
				Log.d(TAG, "token校验结果:" + result);
				JSONObject rjo = new JSONObject(result);
				if (rjo.getString("errorCode") == null) {
					return null;
				}
				if (XConstants.RESULT_CODE_SERVER_SUCCESS == rjo
						.getInt("errorCode")) {
					// 有效期内
					Log.d(TAG, "直接进入游戏...tkn=" + tkn);
					response(XConstants.RESULT_CODE_OK,
							rjo.getJSONObject("bizObj").toString());
					return tkn;
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
			return null;
		}

		protected void onPostExecute(String result) {
			if (result == null) {
				initWebView(BASE_PAGE, curFC, "",
						IWUtils.getEnvInfo(ContainerActivity.this));
				return;
			}
		}

	}

	private void response(int ec, String result) {
		XDispatcherCallback xCallback = XCallbackManager.getXCallback(curCBD);
		if (xCallback != null) {
			xCallback.onFinished(ec, result);
			XCallbackManager.unregistCallback(curCBD);
			curCBD = 0;
			curFC = 0;
		}
		Log.d(TAG, "finished...");
		ContainerActivity.this.finish();
	}
}
