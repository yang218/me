package com.iwgame.app.iwsdk.base;

public abstract interface XDispatcherCallback {
	public abstract void onFinished(int ec,String paramString);
}