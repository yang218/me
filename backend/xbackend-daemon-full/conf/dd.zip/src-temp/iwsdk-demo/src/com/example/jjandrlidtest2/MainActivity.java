package com.example.jjandrlidtest2;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.iwgame.app.iwsdk.IWSDK;
import com.iwgame.app.iwsdk.activity.ContainerActivity;
import com.iwgame.app.iwsdk.base.XConstants;
import com.iwgame.app.iwsdk.base.XDispatcherCallback;
import com.iwgame.app.iwsdk.util.FloatUtil;

public class MainActivity extends ActionBarActivity {

	private static final String TAG = "IWDEMO";

	private Button btn_por;

	private Button btn_lan;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_index);
		Log.i(TAG, "onCreate...");
		btn_por = (Button) findViewById(R.id.btn_por);
		btn_por.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				MainActivity.this.runOnUiThread(new Runnable() {

					@Override
					public void run() {
						Intent baseIntent = new Intent();
						baseIntent.setClass(MainActivity.this,
								GameViewActivity.class);
						baseIntent.putExtra("test_sor", true);
						MainActivity.this.startActivity(baseIntent);
					}
				});
			}
		});

		btn_lan = (Button) findViewById(R.id.btn_lan);
		btn_lan.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				MainActivity.this.runOnUiThread(new Runnable() {

					@Override
					public void run() {
						Intent baseIntent = new Intent();
						baseIntent.setClass(MainActivity.this,
								GameViewActivity.class);
						baseIntent.putExtra("test_sor", false);
						MainActivity.this.startActivity(baseIntent);
					}
				});
			}
		});
		Button btn_exit = (Button) findViewById(R.id.btn_exit);
		btn_exit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				MainActivity.this.runOnUiThread(new Runnable() {

					@Override
					public void run() {
						MainActivity.this.finish();
						android.os.Process.killProcess(android.os.Process
								.myPid());
						System.exit(0);
					}
				});
			}
		});

	}

	@Override
	public void onBackPressed() {
		MainActivity.this.runOnUiThread(new Runnable() {

			@Override
			public void run() {
				MainActivity.this.finish();
				android.os.Process.killProcess(android.os.Process.myPid());
				System.exit(0);
			}
		});
	}
}
