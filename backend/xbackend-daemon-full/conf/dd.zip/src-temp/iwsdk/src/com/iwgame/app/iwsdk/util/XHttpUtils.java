package com.iwgame.app.iwsdk.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

import android.util.Log;

public class XHttpUtils {
	
	private final static String PARAMETER_SEPARATOR = "&";
	private final static String NAME_VALUE_SEPARATOR = "=";
		
	/**
	 * Http GET 请求
	 * @param urlStr
	 * @param params
	 * @return
	 */
	public static String httpGet(String urlStr, Map<String, String> params) {
		
        String result = null;
        URL url = null;
        HttpURLConnection connection = null;
        InputStreamReader in = null;
        try {
        	
    		String paramsEncoded = "";
    		if(params != null){
    			paramsEncoded = urlParamsFormat(params, "UTF-8");
    		}
    		
    		String fullUrl = urlStr + "?" + paramsEncoded;
    		
    		Log.d("IWSDK", "the fullAuthUrl is "+fullUrl);
        	
            url = new URL(fullUrl);
            connection = (HttpURLConnection) url.openConnection();
            
            Log.d("IWSDK", "open connection success");
            
            in = new InputStreamReader(connection.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(in);
            StringBuffer strBuffer = new StringBuffer();
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                strBuffer.append(line);
            }
            result = strBuffer.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
 
        }
        return result;
    }
	
	/**
	 * Http POST 请求
	 * @param urlStr
	 * @param params
	 * @return
	 */
	public static String httpPost(String urlStr, Map<String, String> params) {
				
		
        String result = null;
        URL url = null;
        HttpURLConnection connection = null;
        InputStreamReader in = null;
        try {
        	
    		String paramsEncoded = "";
    		if(params != null){
    			paramsEncoded = urlParamsFormat(params, "UTF-8");
    		}        	
        	
            url = new URL(urlStr);
            connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Charset", "utf-8");
            DataOutputStream dop = new DataOutputStream(
                    connection.getOutputStream());
            dop.writeBytes(paramsEncoded);
            dop.flush();
            dop.close();
 
            in = new InputStreamReader(connection.getInputStream());
            BufferedReader bufferedReader = new BufferedReader(in);
            StringBuffer strBuffer = new StringBuffer();
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                strBuffer.append(line);
            }
            result = strBuffer.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
 
        }
        return result;
    }
	


	
	/**
	 * Returns a String that is suitable for use as an application/x-www-form-urlencoded
     * list of parameters in an HTTP PUT or HTTP POST.
	 * @param params
	 * @param charset
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	public static String urlParamsFormat(Map<String, String> params, String charset) throws UnsupportedEncodingException{
		final StringBuilder sb = new StringBuilder();
		for(String key : params.keySet()){
			final String encodedName = URLEncoder.encode(key, charset);
			final String encodedValue = URLEncoder.encode(params.get(key), charset);
			if(sb.length() > 0){
				sb.append(PARAMETER_SEPARATOR);
			}
			sb.append(encodedName).append(NAME_VALUE_SEPARATOR)
			.append(encodedValue);
			
		}
		
		return sb.toString();
	}
	
}
