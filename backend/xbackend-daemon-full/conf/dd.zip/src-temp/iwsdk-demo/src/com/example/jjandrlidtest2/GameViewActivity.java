/**
 * GameViewActivity.java was created on 2016年12月27日
 * Copyright by jjsky.org
 */
package com.example.jjandrlidtest2;

import com.iwgame.app.iwsdk.IWSDK;
import com.iwgame.app.iwsdk.base.XConstants;
import com.iwgame.app.iwsdk.base.XDispatcherCallback;
import com.iwgame.app.iwsdk.util.FloatUtil;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * @ClassName: GameViewActivity
 * @Description TODO(...)
 * @author yang
 * @date 2016年12月27日 下午7:07:37
 */
public class GameViewActivity extends Activity {

	private static final String TAG = "IWDEMO";

	private static boolean loginFlag;

	private TextView showArea;

	private Button btnLogin;

	private Button btnPay;

	private Button btnQuit;

	private Button btnBind;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		Intent reqIntent = getIntent();
		Bundle extras = reqIntent.getExtras();
		boolean isPor = extras.getBoolean("test_sor");
		Log.i(TAG, "onCreate...>" + isPor);
		if (isPor) {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		setContentView(R.layout.activity_main);
		// 初始化sdk
		IWSDK.getInstance().init(GameViewActivity.this, isPor);

		showArea = (TextView) findViewById(R.id.textView1);

		btnLogin = (Button) findViewById(R.id.btn_login);
		btnLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				Intent baseIntent = new Intent();
				if (loginFlag) {
					Log.i(TAG, "to swich account...");
					baseIntent.putExtra(XConstants.IDKeys.FUNCTION_CODE,
							XConstants.FUNC_CODE_SWICH);
				} else {
					Log.i(TAG, "to login account...");
					baseIntent.putExtra(XConstants.IDKeys.FUNCTION_CODE,
							XConstants.FUNC_CODE_LOGIN);
				}

				IWSDK.getInstance().invokeActivity(GameViewActivity.this,
						baseIntent, new XDispatcherCallback() {

							@Override
							public void onFinished(final int code,
									final String result) {
								Log.i(TAG, "login XDispatcherCallback result="
										+ result);
								GameViewActivity.this
										.runOnUiThread(new Runnable() {

											@Override
											public void run() {
												if (XConstants.RESULT_CODE_OK == code) {
													Toast.makeText(
															GameViewActivity.this,
															"SDK 登录成功："
																	+ result,
															Toast.LENGTH_SHORT)
															.show();
													initLoginStatus(true,
															result);
													// 初始化浮标
													FloatUtil
															.getInstance()
															.createFloatView(
																	GameViewActivity.this);
												} else {
													Toast.makeText(
															GameViewActivity.this,
															"SDK 登录失败："
																	+ result,
															Toast.LENGTH_SHORT)
															.show();
													initLoginStatus(false,
															"未登录");
												}
											}
										});
							}
						});
			}
		});

		btnPay = (Button) findViewById(R.id.btn_pay);
		btnPay.setVisibility(View.GONE);
		btnPay.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				Log.i(TAG, "pay clicked...");
				IWSDK.getInstance().pay(new XDispatcherCallback() {

					@Override
					public void onFinished(final int code, final String result) {
						Log.i(TAG, "btnPay XDispatcherCallback result="
								+ result);
						GameViewActivity.this.runOnUiThread(new Runnable() {

							@Override
							public void run() {
								Toast.makeText(GameViewActivity.this,
										"SDK 支付结果：" + result,
										Toast.LENGTH_SHORT).show();
								showArea.append("\n支付结果:" + result);
							}
						});
					}
				});
			}
		});

		btnQuit = (Button) findViewById(R.id.btn_quit);
		btnQuit.setVisibility(View.GONE);
		btnQuit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				Log.i(TAG, "quit clicked...");
				IWSDK.getInstance().quitSDK(new XDispatcherCallback() {

					@Override
					public void onFinished(final int ec, String result) {
						GameViewActivity.this.runOnUiThread(new Runnable() {
							public void run() {
								Log.i(TAG, "退出返回结果:" + ec);
								switch (ec) {
								case XConstants.RESULT_CODE_OK:
									GameViewActivity.this.finish();
									android.os.Process
											.killProcess(android.os.Process
													.myPid());
									System.exit(0);
									break;
								default:
									showArea.append("\n退出返回码:" + ec);
									break;
								}
							}
						});
					}
				});
			}
		});
		btnBind = (Button) findViewById(R.id.btn_bind);
		btnBind.setVisibility(View.GONE);
		btnBind.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View view) {
				Log.i(TAG, "bind clicked...");
				IWSDK.getInstance().bindAccount(new XDispatcherCallback() {

					@Override
					public void onFinished(int ec, String result) {
						Log.i(TAG, "iwsdk返回绑定结果:" + result);
						if (XConstants.RESULT_CODE_OK == ec) {
							showArea.append("绑定成功,数据=" + result);
						} else {
							showArea.append("\n绑定异常,返回码:" + ec + ",数据="
									+ result);
						}
					}
				});
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onStart() {
		super.onStart();
		Log.i(TAG, "onStart...");
	}

	@Override
	protected void onResume() {
		super.onResume();
		Log.i(TAG, "onResume...");
	}

	@Override
	protected void onPause() {
		super.onPause();
		Log.i(TAG, "onPause...");

	}

	@Override
	protected void onStop() {
		super.onStop();
		Log.i(TAG, "onStop...");

	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		Log.i(TAG, "onDestroy...");
		IWSDK.getInstance().destory();
	}

	private void initLoginStatus(boolean isLogin, String account) {
		showArea.setText("登录信息:" + account);
		if (!isLogin) {
			loginFlag = false;
			btnLogin.setText("登录");
			btnPay.setVisibility(View.GONE);
			btnQuit.setVisibility(View.GONE);
			btnBind.setVisibility(View.GONE);
		} else {
			loginFlag = true;
			btnLogin.setText("切换帐号");
			btnPay.setVisibility(View.VISIBLE);
			btnQuit.setVisibility(View.VISIBLE);
			btnBind.setVisibility(View.VISIBLE);
		}
	}

	@Override
	public void onBackPressed() {
//		super.onBackPressed();
//		GameViewActivity.this.finish();
//		android.os.Process.killProcess(android.os.Process.myPid());
//		System.exit(0);
	}
}
