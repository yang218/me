package com.iwgame.app.iwsdk.base;

import java.util.HashMap;
import java.util.Map;

public class XCallbackManager {

	private static Map<Long, XDispatcherCallback> callbackCache = new HashMap<Long, XDispatcherCallback>();

	public synchronized static Long registCallback(XDispatcherCallback callback) {
		long now = System.currentTimeMillis();
		callbackCache.put(now, callback);
		return now;
	}

	public static XDispatcherCallback getXCallback(Long callbackId) {
		return callbackCache.get(callbackId);
	}

	public static void unregistCallback(Long key) {
		callbackCache.remove(key);
	}
}
